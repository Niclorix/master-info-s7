function [ y ] = parabole( x )
y = x.*x -1;
end

